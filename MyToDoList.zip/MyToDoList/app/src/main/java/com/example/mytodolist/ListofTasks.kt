package com.example.mytodolist

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ListofTasks : AppCompatActivity(), TaskAdapterListener {
    private lateinit var recyclerView: RecyclerView
    private lateinit var taskAdapter: TaskAdapter
    private var taskList: ArrayList<TaskModel> = ArrayList()
    private lateinit var addTaskButton: FloatingActionButton
    private lateinit var emptyTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.recycler_view)

        recyclerView = findViewById(R.id.recyclerView)
        addTaskButton = findViewById(R.id.addTaskButton)
        emptyTextView = findViewById(R.id.emptyTextView)

        taskAdapter = TaskAdapter(taskList, this)

        recyclerView.apply {
            layoutManager = LinearLayoutManager(this@ListofTasks)
            adapter = taskAdapter
        }

        checkEmptyState()

        addTaskButton.setOnClickListener {
            showAddTaskDialog()
        }
    }

    private fun showAddTaskDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add Task")

        val view = LayoutInflater.from(this).inflate(R.layout.add_task, null)
        val taskTitleInput = view.findViewById<EditText>(R.id.taskTitleInput)
        val taskDescriptionInput = view.findViewById<EditText>(R.id.taskDescriptionInput)
        builder.setView(view)

        builder.setPositiveButton("Add") { _, _ ->
            val taskTitle = taskTitleInput.text.toString().trim()
            val taskDescription = taskDescriptionInput.text.toString().trim()
            if (taskTitle.isNotEmpty()) {
                taskList.add(TaskModel(taskTitle, taskDescription, false))
                taskAdapter.notifyItemInserted(taskList.size - 1)
                checkEmptyState()
            }
        }
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.dismiss()
        }

        builder.create().show()
    }

    override fun checkEmptyState() {
        if (taskList.isEmpty()) {
            emptyTextView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            emptyTextView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }
}
