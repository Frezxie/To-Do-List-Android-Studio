package com.example.mytodolist

data class TaskModel(
    val title: String,
    val description: String,
    var isCompleted: Boolean
)



