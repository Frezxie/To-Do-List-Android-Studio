package com.example.mytodolist

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

interface TaskAdapterListener {
    fun checkEmptyState()
}

class TaskAdapter(
    private val taskList: ArrayList<TaskModel>,
    private val listener: TaskAdapterListener
) : RecyclerView.Adapter<TaskAdapter.TaskViewHolder>() {

    inner class TaskViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val taskTitle: TextView = view.findViewById(R.id.taskTitle)
        val taskDescription: TextView = view.findViewById(R.id.taskDescription)
        val checkBox: CheckBox = view.findViewById(R.id.checkBox)
        val deleteButton: ImageButton = view.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.task_item, parent, false)
        return TaskViewHolder(view)
    }

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = taskList[position]

        holder.taskTitle.text = task.title
        holder.taskDescription.text = task.description
        holder.checkBox.isChecked = task.isCompleted

        holder.deleteButton.setOnClickListener {
            val context = holder.itemView.context
            AlertDialog.Builder(context)
                .setTitle("Delete Task")
                .setMessage("Are you sure you want to delete this task?")
                .setPositiveButton("Yes") { _, _ ->
                    taskList.removeAt(position)
                    notifyItemRemoved(position)
                    notifyItemRangeChanged(position, taskList.size)

                    Toast.makeText(context, "Task deleted successfully", Toast.LENGTH_SHORT).show()

                    listener.checkEmptyState()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun getItemCount(): Int {
        return taskList.size
    }
}
